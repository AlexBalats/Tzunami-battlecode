// Prices (R9 50_prices): price every option in team gems per round; the updater (upd.cpp) chooses.
#pragma once
#include "types.h"
#include "world.h"
#include "snap.h"
#include "memory.h"
#include "state.h"
#include "champs.h"

// constants [R9, tags as in 50_prices]
constexpr float HYST = 1.2f;
constexpr float KILL_PL_POW_06 = 0.756f, KILL_PL_POW_095 = 0.231f;
constexpr float P_NEAR = 0.5f;
constexpr float WAIT_PARTNER = 15;
constexpr int OPEN_END = 100;
constexpr int GROUP_UNTIL = 300;
constexpr float GROUP_SOLO_MAX = 0.4f, GROUP_GEMS_MIN = 0.7f;
constexpr float BODY_EXP = 1.0f, STACK_BODY_EXP = 0.0f;
constexpr float STACK_WAIT_PARTNER = 0;
constexpr int BANK_NEAR = 8; constexpr float BANK_NEAR_BONUS = 1.0f;
constexpr int GROUP_BANK_BAG = 100; constexpr float GROUP_BANK_X = 12.0f;
constexpr int SHOP_MUST = 300; constexpr float SHOP_MUST_X = 3.0f;
constexpr float STACK_FOLLOW = 3.0f;
constexpr int SPAWN_KILL_R = 2;
constexpr float FARM_PLOSE = 0.99f;
constexpr float HEAL_K = 1.5f, MY_RATE = 0.4f; constexpr int DEATH_OUT = 60;
constexpr float DCOST_CAP = 300, HEAL_NOENEMY_CAP = 150, HEAL_NOENEMY_HP = 0.5f;
constexpr float ATTACKER_BONUS = 1.5f;
constexpr int HOLD_TURNS = 2;
constexpr float KILL_PER_SHARD = 0.15f;
constexpr int STACK_N = 3, STACK_N_FEW = 2, STACK_R = 10;
constexpr float STACK_FARM = 0.2f;
constexpr int PUNISH_LEAD = 50;
constexpr float STACK_HEAL = 0.6f, HEAL_PLOSE = 0.5f;
constexpr int JOIN_FIGHT_R = 10, JOIN_TTK = 3; constexpr float JOIN_NEED = 0.3f;
constexpr int LANCH_NEAR = 4, LANCH_R = 8; constexpr float LANCH_FAR_W = 0.5f;
constexpr float GROUP_KILL_X = 2.0f, REWARD_X = 1.0f;
constexpr int WAIT_MAX = 15;     // rounds a body may stand at a respawning group's Ring (ROUTING U1.5) // GUESS
constexpr int FLIP_WINDOW = 10, FLIP_LOCK = 30;
constexpr float STUN_F = 0.3f, REN_RET = 0.2f;
constexpr float HOR_DMG_X = 1.25f;   // GUESS: Heart of Ruin's missing-health bonus, mean over a fight from full to dead (0 to +50 %)
constexpr int FIGHT_FARM = 2, HP_STEP = 50;
constexpr float HEAL_LOW = 0.3f, HEAL_FLOOR = 0.8f; constexpr int HEAL_WB = 15;
constexpr float SUNK_K = 2.0f; constexpr int PROG_STALL = 8;
constexpr int HUNT_BAG = 30, HUNT_REVISIT = 150, ROAM_STACK = 60, HUNT_MAX = 40;
constexpr float KILL_PRICE = 1.0f, G2G_K = 0.5f; constexpr int SHUT_GATE = 500;
constexpr int RACE_RICH = 4;
constexpr int SEED_UNTIL = 40;
constexpr int NEAR6 = 6;

struct Posture { float farm = 1, farm_their_side = 1, bank_risk = 1, kill_our_side = 1, kill_their_side = 1, shop = 1, join = 1, ward = 1, heal = 1; };
struct Race { float walk_w, farm_hyst, wait; int bank_ret; };
struct Price { float p; Beh op; int tg; };
constexpr int MAXPR = 40;

float g2g(int r);
bool group_map(const World& w);
bool stack_mode(const World& w, int r);
const Race& race(const World& w);
int sub_size(const World& w);
bool near_espawn(const World& w, vec2 p);
int stack_n(const World& w);
const Posture& posture(const World& w, const Snap& s);
float duel(const World& w, const Snap& s);
bool flee_ok(const Snap& s);
bool retreat_now(const World& w, const Snap& s);
bool engaged(const Snap& s, int g);
void bank_altar(const World& w, const Snap& s, const Mem& mem, int gn, int* a_out, u16* wk_out);
float farm_price(const World& w, const Snap& s, const Mem& mem, int g, int bodies, float walk, int c);
int need_k_r9(const World& w, const Snap& s, const Mem& mem, int g, int c);   // 0 = none
bool can_finish_r9(const World& w, const Snap& s, const Mem& mem, int g, int k, float hp);
float walk_home(const World& w, vec2 p);
int near6(const World& w, int* out);        // the NEAR6 nearest groups by F_me (NAV.gd)
void pre_turn(const World& w, Snap& s, const Mem& mem);   // trapped, edps, plose, score: before any decision
// the per-turn claims (set by the updater before price_all)
struct Claims { int cl[MAXG]; bool lowcl[MAXG]; int lowcn[MAXG]; bool lowsub[MAXG]; u8 by_op[5]; u8 by_tg[5]; };
extern Claims CL;
int price_all(const World& w, Snap& s, Mem& mem, Price* out);   // returns the count
int kill_target_count(const Snap& s);
