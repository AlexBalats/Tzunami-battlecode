// Mem (memory.h).
#include "memory.h"
#include <vector>

extern std::vector<cambc::map::camp_group> GROUPS;
Mem MEM;

void Mem::init(const World& w)
{
    for (int g = 0; g < MAXG; ++g) { st[g] = GState::Alive; until[g] = 0; seen[g] = -1; for (int i = 0; i < MAXCG; ++i) hp[g][i] = -1; }
    nseen = 0; loud = -99; nbush = 0; last_pos = w.sp0; last_hp = 0; last_bag = 0; last_gold = 0;
}

void Mem::note_bush(vec2 q, int r)
{
    for (int i = 0; i < nbush; ++i) if (bush[i] == q) { bush_r[i] = r; loud = r; return; }
    if (nbush < 16) { bush[nbush] = q; bush_r[nbush] = r; ++nbush; }
    loud = r;
}

void Mem::observe_group(const World& w, Snap& s, int g)
{
    if (g < 0 || g >= w.nG || seen[g] == s.r) return;
    // any live camp of g seen this turn: alive, with its HP
    bool any = false;
    for (int i = 0; i < s.nlive; ++i) if (s.live[i].g == g) { any = true; break; }
    if (any)
    {
        st[g] = GState::Alive; seen[g] = s.r;
        bool vis_all = true;
        for (int i = 0; i < w.G[g].n; ++i)
        {
            bool found = false;
            for (int k = 0; k < s.nlive; ++k) if (s.live[k].g == g && s.live[k].i == i) { hp[g][i] = s.live[k].hp; found = true; }
            if (!found) { if (cambc::vision::in_vision(w.G[g].tiles[i])) hp[g][i] = 0; else vis_all = false; }
        }
        (void)vis_all;
        return;
    }
    // no live camp seen: ask the engine only if a spawn tile is in vision
    bool vis = false;
    for (int i = 0; i < w.G[g].n && !vis; ++i) vis = cambc::vision::in_vision(w.G[g].tiles[i]);
    if (!vis) return;
    seen[g] = s.r;
    try
    {
        const auto gs = GROUPS[g].state();
        if (std::holds_alternative<cambc::map::camp_group_reward_available>(gs)) { st[g] = GState::Reward; for (int i = 0; i < MAXCG; ++i) hp[g][i] = 0; }
        else if (auto* rs = std::get_if<cambc::map::camp_group_respawning>(&gs)) { st[g] = GState::Resp; until[g] = s.r + rs->timer + 1; for (int i = 0; i < MAXCG; ++i) hp[g][i] = -1; }
        else { st[g] = GState::Alive; }
    }
    catch (...) {}
}

void Mem::update(const World& w, Snap& s)
{
    const int r = s.r;
    if (s.unseen_hit) uhit = r;
    // respawn timers expire on their own
    for (int g = 0; g < w.nG; ++g) if (st[g] == GState::Resp && until[g] <= r) { st[g] = GState::Alive; for (int i = 0; i < MAXCG; ++i) hp[g][i] = -1; }
    // the death event: avoid that group
    // enemies
    for (int i = 0; i < s.ne; ++i)
    {
        const Enemy& e = s.e[i];
        int k = -1;
        for (int j = 0; j < nseen; ++j) if (en[j].h == e.h) { k = j; break; }
        if (k < 0) { if (nseen < 10) k = nseen++; else k = 0; }
        en[k].h = e.h; en[k].r = r; en[k].p = e.p; en[k].hp = e.hp; en[k].str = e.str; en[k].range = e.range;
        if (e.d <= 12) loud = r;
    }
    for (int j = 0; j < nseen;) { if (r - en[j].r > MEM_FIGHT) { en[j] = en[--nseen]; } else ++j; }
    for (int i = 0; i < nbush;) { if (r - bush_r[i] > BUSH_AGE) { bush[i] = bush[--nbush]; bush_r[i] = bush_r[nbush]; } else ++i; }
    // groups I can judge this turn: my current one and the nearest ones
    for (int g = 0; g < w.nG; ++g) if (g == s.cur_g || cheb(w.G[g].anchor, s.pos) <= 11) observe_group(w, s, g);
}

int Mem::enemies_near(vec2 p, int r, int within) const
{
    int n = 0;
    const int now = (int)cambc::round_number();
    for (int j = 0; j < nseen; ++j) if (now - en[j].r <= within && cheb(en[j].p, p) <= r) ++n;
    return n;
}
