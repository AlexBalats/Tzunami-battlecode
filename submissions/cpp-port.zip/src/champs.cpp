// Champion data (champs.h), R9 20_champs ported constant for constant.
#include "champs.h"
#include "kit.h"

Me ME;
using I = cambc::item_type;

struct Row { float farm, bank, kill, shop, join, heal; bool splash; };
// draft id -> base row [R9 PROFILES, guess all]
static Row base_row(int id)
{
    switch (id)
    {
    case 0: return { 1.1f, 0.9f, 1.2f, 1.0f, 1.2f, 1.0f, false };   // Ryth
    case 2: return { 1.1f, 1.1f, 1.3f, 1.0f, 1.0f, 1.0f, false };   // Vendetta
    case 9: return { 1.3f, 1.0f, 0.8f, 1.0f, 1.2f, 1.0f, true };    // Varg (splash)
    case 6: return { 1.1f, 0.8f, 1.1f, 1.0f, 1.1f, 1.0f, false };   // Marcella
    case 1: return { 1.2f, 1.1f, 0.9f, 1.0f, 1.0f, 1.0f, false };   // Vesper Vale (phases below)
    case 4: return { 1.5f, 1.2f, 1.2f, 1.0f, 1.2f, 1.0f, false };   // Stellar
    case 8: return { 1.1f, 1.0f, 1.2f, 1.0f, 1.1f, 1.0f, false };   // Ren
    default: return { 1, 1, 1, 1, 1, 1, false };                     // neutral
    }
}
// Cassi (type 3) / Issac (type 4) rows by ChampionType [R9 TYPE_ROWS]
static bool type_row(int t, Row& r)
{
    if (t == 3) { r = { 1.1f, 1.2f, 1.0f, 1.0f, 1.0f, 2.0f, false }; return true; }
    if (t == 4) { r = { 1.1f, 1.0f, 1.1f, 1.0f, 1.1f, 1.0f, false }; return true; }
    return false;
}

void Me::init(const World& w)
{
    shards = 0; shards_r = -99; phase = -1; spike = false;
    switch (w.role)
    {
    case Role::Main: nbuild = 4; build[0] = I::home_shard_of_strength; build[1] = I::treasure_shard_of_strength; build[2] = I::monster_shard_of_strength; build[3] = I::power_shard_of_strength; break;
    case Role::Second: nbuild = 2; build[0] = I::power_shard_of_strength; build[1] = I::jungle_shard_of_strength; break;
    default: nbuild = 3; build[0] = I::jungle_shard_of_strength; build[1] = I::power_shard_of_strength; build[2] = I::durability_shard_of_health; break;
    }
    alt[0] = I::durability_shard_of_health; alt[1] = I::power_shard_of_strength;
    target = build[0]; need = 150;
    apply_phase(w);
}

void Me::apply_phase(const World& w)
{
    Row b; if (!type_row(w.my_type, b)) b = base_row(w.my_id);
    Prof p;
    p.farm = b.farm; p.bank = b.bank; p.kill = b.kill; p.shop = b.shop; p.join = b.join; p.heal = b.heal; p.splash = b.splash;
    int i = 0;
    if (w.my_id == 1)
    {
        // Vesper's phases [R9 user plan 15 Oct]: < 15 shards farm; from 15 hunt
        if (shards >= 15) { i = 1; p.farm = 0.4f; p.kill = 2.5f; p.bank = 1.5f; p.shop = 0.5f; p.hunt = 20; p.chase = 8; p.heal = 0.5f; p.retreat_hp = 0.3f; p.kill_plose = 0.95f; p.dcost_fight = 30; p.denial = 60; p.patrol = true; }
        else { i = 0; p.farm = 1.5f; p.kill = 0.9f; p.bank = 1.1f; p.shop = 2.0f; p.hunt = 6; p.chase = 6; p.denial = 60; p.patrol = false; }
    }
    p.gold = ROLE_GOLD[(int)w.role];
    const bool spk = spike && w.role != Role::Main;
    if (spk) { if (p.gold < SPIKE_GOLD) p.gold = SPIKE_GOLD; p.shop = SPIKE_SHOP; }
    const int key = i * 2 + (spk ? 1 : 0);
    if (key == phase) return;
    phase = key; prof = p;
    TR("phase", "%d role=%d shards=%d gold=%.2f farm=%.2f kill=%.2f hunt=%d%s", i, (int)w.role, shards, p.gold, p.farm, p.kill, p.hunt, spk ? " spike" : "");
}

int Me::shards_owned(const World& w)
{
    int t = 0;
    try
    {
        const auto n = w.me->item_count();
        for (u32 k = 0; k < (u32)I::count; ++k)
        {
            const I it = (I)k;
            const u32 c = n[it]; if (!c) continue;
            const auto res = it.result();
            if (res) t += (int)c;                              // a shard
            else
            {
                // an emblem counts the shards it took: find the shard whose result is it
                for (u32 j = 0; j < (u32)I::count; ++j) { const I sh = (I)j; const auto r2 = sh.result(); if (r2 && *r2 == it) { t += (int)(c * sh.combine_count()); break; } }
            }
        }
    }
    catch (...) {}
    return t;
}

// first build entry whose emblem is not complete; all complete: the alt family with fewer emblems (ties: later) [R9]
static I build_target(const World& w, const Me& me, u32* have_out)
{
    const auto n = w.me->item_count();
    for (int i = 0; i < me.nbuild; ++i)
    {
        const I it = me.build[i];
        const u32 cnt = n[it]; const u32 cc = it.combine_count(); const auto res = it.result();
        if (cnt >= cc) continue;
        if (res && n[*res] > 0) continue;
        if (have_out) *have_out = cnt;
        return it;
    }
    I best = me.alt[0]; u32 bc = 0xFFFFFFFFu;
    for (int i = 0; i < 2; ++i)
    {
        const I it = me.alt[i]; const u32 cnt = n[it]; const u32 cc = it.combine_count(); const auto res = it.result();
        if (cnt > 0 && cnt < cc) { if (have_out) *have_out = cnt; return it; }
        const u32 c = res ? n[*res] : 0;
        if (c <= bc) { bc = c; best = it; }
    }
    if (have_out) *have_out = n[best];
    return best;
}

bool Me::buy_all(const World& w, const Snap& s)
{
    int bought = 0;
    try
    {
        for (int it = 0; it < 10; ++it)
        {
            u32 have = 0;
            const I item = build_target(w, *this, &have);
            target = item;
            if (!w.me->can_buy(item)) { need = (int)(item.cost() * (item.combine_count() - have)); break; }
            w.me->buy(item); ++bought;
            TR("shop", "buy %u gold=%u", (unsigned)item, (unsigned)w.me->gold_count());
        }
        if (s.gold >= LOCK_GOLD && w.me->consumables()[cambc::consumable_type::altar_lock].count() == 0 && w.me->can_buy(cambc::consumable_type::altar_lock))
            w.me->buy(cambc::consumable_type::altar_lock);
    }
    catch (...) {}
    if (bought) KIT.refresh(w);
    return bought > 0;
}
