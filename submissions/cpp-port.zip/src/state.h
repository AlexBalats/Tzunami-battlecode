// The play-side frame shared by prices, behaviours, the updater and main (R9: the fields on World / the Behaviors).
#pragma once
#include "types.h"
#include "world.h"
#include "snap.h"

constexpr int EXCL = 20;            // rounds an (option, target) is excluded after a timeout / failure [R9]
constexpr int DEATH_EXCL = 100;     // rounds a death excludes its (option, target), and kill/hunt after a kill/hunt death [R9]
constexpr int KFAIL_ROUNDS = 6, KFAIL_MAX = 48;   // a failed chase bans the target, doubling per consecutive failure [R9]
constexpr int NKF = 16;

inline bool operator==(Choice a, Choice b) { return a.beh == b.beh && a.target == b.target; }

struct State
{
    // the frame
    Choice cur; int started = 0; Status status = Status::Done; int deadline = 0;
    float prog = 0, pbest = 0; int pstall = 0; int d0 = -1;   // sunk progress [R9 IMPROVEMENTS 2]
    bool hit = false;               // attacked since this choice
    // per-turn flags (last turn's are read by the guards)
    bool attacked = false, capt = false, waiting = false;
    // exclusions (option, target) -> round
    int excl_farm[MAXG], excl_bank[MAXA], excl_hunt_a[MAXA], excl_hunt_g[MAXG], excl_join[6], excl_shop = 0;
    struct KF { u32 h = 0; int until = 0; int n = 0; } kf[NKF]; int nkf = 0;   // kill bans and consecutive failures (Kill.kfail / kfn)
    int kh_until = 0;               // no kill / hunt until (a kill/hunt death)
    // prices' long-lived
    float rawb = 0;                 // last full turn's best raw farm price [R9 08 F1]
    float roam = 0; int big3 = -999;
    int post = -1;                  // posture traced
    bool sm = false; int sm_r = -1; // stack mode cache
    bool race_set = false, race_fast = false;
    // the opening
    int seed = -1, seed_until = 0;
    u8 subs[6] = { 0, 0, 0, 0, 0, 0 };   // my subgroup as a slot bitmask (0: none)
    int subs_r = 0;
    // Farm's long-lived
    int pair_until = 0;
    int fh_r[3], fh_g[3], nfh = 0; int flips = 0;
    // Hunt's patrol visits
    int hvis_a[MAXA], hvis_g[MAXG];
    // death bookkeeping
    bool was_alive = true; int deaths = 0;
    int stay = 0, idle = 0;
    int act[7] = { 0, 0, 0, 0, 0, 0, 0 };

    void init()
    {
        for (int g = 0; g < MAXG; ++g) { excl_farm[g] = 0; excl_hunt_g[g] = 0; hvis_g[g] = -999; }
        for (int a = 0; a < MAXA; ++a) { excl_bank[a] = 0; excl_hunt_a[a] = 0; hvis_a[a] = -999; }
        for (int k = 0; k < 6; ++k) excl_join[k] = 0;
    }
    int& excl_of(Beh op, int tg)
    {
        static int dummy;
        switch (op)
        {
        case Beh::Farm: return tg >= 0 && tg < MAXG ? excl_farm[tg] : dummy;
        case Beh::Bank: return tg >= 0 && tg < MAXA ? excl_bank[tg] : dummy;
        case Beh::Hunt: return tg >= 100 ? (tg - 100 < MAXG ? excl_hunt_g[tg - 100] : dummy) : (tg >= 0 && tg < MAXA ? excl_hunt_a[tg] : dummy);
        case Beh::Join: return tg >= 0 && tg < 6 ? excl_join[tg] : dummy;
        case Beh::Shop: return excl_shop;
        default: dummy = 0; return dummy;
        }
    }
    KF* kf_find(u32 h) { for (int i = 0; i < nkf; ++i) if (kf[i].h == h) return &kf[i]; return nullptr; }
    KF& kf_get(u32 h) { KF* k = kf_find(h); if (k) return *k; if (nkf < NKF) { kf[nkf] = KF{ h, 0, 0 }; return kf[nkf++]; } kf[0] = KF{ h, 0, 0 }; return kf[0]; }
    int kfail(u32 h) { const KF* k = kf_find(h); return k ? k->until : -1; }
    void ban(u32 h, int r)
    {
        KF& k = kf_get(h); k.n += 1;
        int b = KFAIL_ROUNDS << (k.n - 1 < 6 ? k.n - 1 : 6); if (b > KFAIL_MAX) b = KFAIL_MAX;
        k.until = r + b;
        if (k.n > 1) TR("exec", "kill %u ban x%d until r%d", h, k.n, k.until);
    }
    bool excluded(Beh op, int tg, int r)
    {
        if (op == Beh::Kill) return kfail((u32)tg) > r;
        if (op == Beh::Heal || op == Beh::Fall || op == Beh::Idle || op == Beh::Dead) return false;
        return excl_of(op, tg) > r;
    }
    void exclude(Beh op, int tg, int r_until)
    {
        if (op == Beh::Kill) { KF& k = kf_get((u32)tg); if (k.until < r_until) k.until = r_until; return; }
        int& e = excl_of(op, tg); if (e < r_until) e = r_until;
    }
};
extern State ST;
