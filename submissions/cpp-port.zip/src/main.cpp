// Entry (R9 90_main): the draft loop and the play loop: sense, decode, the dead gate, memory, reflexes, the guards,
// act (<= 2x decide + execute), the scan ward, encode, Nav.order; the fuel ledger (09 H1) scaled to the C++ turn.
#include "types.h"
#include "world.h"
#include "snap.h"
#include "memory.h"
#include "comms.h"
#include "nav.h"
#include "kit.h"
#include "state.h"
#include "prices.h"
#include "beh.h"
#include "upd.h"
#include "champs.h"
#include "draft.h"

State ST;
static Snap S;
static bool BOOTED = false;
static int ERRS = 0;
static std::uint64_t FMAX = 0, FSUM = 0; static int FN = 0, ROLL = 0;
static std::uint64_t PH[4] = { 0, 0, 0, 0 };

// the ledger [R9 09 H1, scaled: 2.5M -> 100k]
constexpr u32 EXEC_RES = 28000;     // GUESS execute's reserve
constexpr int DEC_N = 16; constexpr float DEC_Q = 0.75f;
constexpr u32 DEC_COST0 = 40000;    // GUESS before one is measured
constexpr int FRESH_E = 4, DEC_SKIP = 4;
static u32 CDEC[2][DEC_N]; static int NDEC[2] = { 1, 1 };   // full / cheap
static int DSKIP = 0; static bool NE4 = false; static int NDECS[3] = { 0, 0, 0 };
static int FME_WAIT = 0;
static int SHARDS_FUEL_TRACED = 0;

static u32 dec_cost(int cheap)
{
    u32 d[DEC_N]; const int n = NDEC[cheap];
    for (int i = 0; i < n; ++i) d[i] = CDEC[cheap][i];
    for (int i = 1; i < n; ++i) for (int j = i; j > 0 && d[j] < d[j - 1]; --j) std::swap(d[j], d[j - 1]);
    return d[(int)(n * DEC_Q) < n ? (int)(n * DEC_Q) : n - 1];
}
static void dec_push(int cheap, u32 c)
{
    if (NDEC[cheap] < DEC_N) CDEC[cheap][NDEC[cheap]++] = c;
    else { for (int i = 1; i < DEC_N; ++i) CDEC[cheap][i - 1] = CDEC[cheap][i]; CDEC[cheap][DEC_N - 1] = c; }
}
static void dec_age(int cheap)
{
    if (NDEC[cheap] > 1) { for (int i = 1; i < NDEC[cheap]; ++i) CDEC[cheap][i - 1] = CDEC[cheap][i]; NDEC[cheap]--; }
    else CDEC[cheap][0] = CDEC[cheap][0] * 9 / 10;
}

static bool can_decide(const Snap& s, int k)
{
    if (s.recalling || s.submitting) return false;
    S.cheap = false;
    const int fc = s.near_e <= 8 ? 1 : 0;
    if (fuel() > dec_cost(fc) + EXEC_RES) return true;
    dec_age(fc);
    if (k == 0 && (s.attacker || (s.near_e <= FRESH_E && !NE4) || ST.status != Status::Going || DSKIP >= DEC_SKIP))
    {
        S.cheap = true;
        return fuel() > dec_cost(1) + ((s.attacker || s.near_e <= FRESH_E) ? 0 : EXEC_RES);
    }
    return false;
}

static void dead_gate(World& w)
{
    ST.act[6]++;
    if (ST.was_alive)
    {
        TR("death", "bag=%d pos=%d,%d hp=%.0f cur=%d:%d enemies=%d", MEM.last_bag, MEM.last_pos.x, MEM.last_pos.y, MEM.last_hp, (int)ST.cur.beh, ST.cur.target, S.ne);
        ST.was_alive = false; ST.deaths++;
        const Choice c = ST.cur;
        ST.exclude(c.beh, c.target, S.r + DEATH_EXCL);
        if (c.beh == Beh::Kill || c.beh == Beh::Hunt) ST.kh_until = S.r + DEATH_EXCL;
        if (c.beh == Beh::Farm && c.target >= 0 && c.target < w.nG && w.G[c.target].mi < 31) Comms::mark_death(w.G[c.target].mi, S.r);
        ST.cur = Choice{ Beh::Dead, -1 }; ST.status = Status::Done;
    }
    if (S.gold >= 30) ME.buy_all(w, S);
    Comms::encode(w, S, Beh::Dead, -1);
}

static void reflexes(World& w)
{
    const int r = S.r;
    if (S.spawn && S.gold >= 30) ME.buy_all(w, S);
    if (!ME.spike)
    {
        float vs = w.role == Role::Main ? S.S : 0;
        for (int i = 0; i < S.na; ++i) if (S.a[i].slot == w.main_slot && S.a[i].str > vs) vs = S.a[i].str;
        if (vs >= SPIKE_STR || r >= SPIKE_ROUND) { ME.spike = true; TR("phase", "spike r=%d vstr=%.0f", r, vs); ME.apply_phase(w); }
    }
    if (r - ME.shards_r >= 20)
    {
        ME.shards_r = r;
        const auto f0 = fuel();
        ME.shards = ME.shards_owned(w);
        ME.apply_phase(w);
        KIT.refresh(w);
        if (SHARDS_FUEL_TRACED < 2) { TR("shards", "n=%d fuel=%llu", ME.shards, (unsigned long long)(f0 - fuel())); SHARDS_FUEL_TRACED++; }
    }
    if (S.can_cast && !S.recalling && !S.submitting) KIT.shield(w, S, S.hp < MEM.last_hp, nullptr);
}

static void guards(World& w, bool f_attacked, bool f_capt, bool f_waiting)
{
    const int r = S.r;
    if (!ST.was_alive) { ST.was_alive = true; ST.status = Status::Done; FME_WAIT = 1; }
    else if (cheb(S.pos, NAV.fme_root) > FME_MOVE) { if (FME_WAIT < 1) FME_WAIT = 1; }
    if (FME_WAIT)
    {
        if (NAV.can_build(EXEC_RES + (FME_WAIT == 1 ? dec_cost(S.near_e <= 8) : 0))) { NAV.build_fme(w, S.pos); FME_WAIT = 0; }
        else FME_WAIT++;
    }
    bool exempt = f_attacked || f_capt || S.recalling || S.submitting;
    if (f_waiting && !exempt && stack_mode(w, r)) exempt = true;
    ST.stay = (S.pos == MEM.last_pos && !exempt) ? ST.stay + 1 : 0;
    if (ST.stay == 30) TR("stay", "%d,%d %d:%d wait=%d", S.pos.x, S.pos.y, (int)ST.cur.beh, ST.cur.target, (int)f_waiting);
    if (ST.status == Status::Going)
    {
        // sunk progress and the stall guard
        float p = beh_progress(w, S, MEM, ST.cur, f_attacked); if (p < 0) p = 0; if (p > 1) p = 1;
        ST.prog = p;
        if (p > ST.pbest + 1e-6f) { ST.pbest = p; ST.pstall = 0; } else ST.pstall++;
        const bool seek = beh_seeking();
        const Beh b = ST.cur.beh;
        if (exempt || f_waiting || seek || !(b == Beh::Farm || b == Beh::Bank || b == Beh::Join || b == Beh::Hunt)) ST.pstall = 0;
        else if (ST.pstall >= PROG_STALL)
        {
            TR("exec", "%d:%d failed stall prog=%.2f", (int)b, ST.cur.target, ST.prog);
            ST.exclude(b, ST.cur.target, r + EXCL); ST.status = Status::Failed; ST.pstall = 0;
        }
    }
    if (ST.status == Status::Going && r > ST.deadline && !(S.recalling || S.submitting))
    {
        TR("exec", "%d:%d failed timeout", (int)ST.cur.beh, ST.cur.target);
        if (ST.cur.beh == Beh::Heal && heal_stuck(S)) TR("heal", "stuck %d,%d hp=%.0f uhit=%d", S.pos.x, S.pos.y, S.hp, r - MEM.uhit);
        if (ST.cur.beh == Beh::Kill) { ST.ban((u32)ST.cur.target, r); }
        else ST.exclude(ST.cur.beh, ST.cur.target, r + EXCL);
        ST.status = Status::Failed;
    }
}

static void act(World& w)
{
    const int r = S.r;
    for (int k = 0; k < 2; ++k)
    {
        if (can_decide(S, k))
        {
            const auto fb = fuel();
            upd_decide(w, S, MEM);
            const u32 c = (u32)(fb - fuel());
            if (c > PH[1]) PH[1] = c;
            dec_push(S.cheap || S.near_e <= 8 ? 1 : 0, c);
            DSKIP = 0; NDECS[S.cheap ? 1 : 0]++;
        }
        else if (k == 0) { DSKIP++; NDECS[2]++; }
        const Choice c = ST.cur;
        if (c.beh == Beh::Idle || c.beh == Beh::Dead) break;
        const auto fb = fuel();
        NAV.fail = NavRes::Here;
        Status st = beh_execute(w, S, MEM, c);
        { const auto cc = fb - fuel(); if (cc > PH[2]) PH[2] = cc; }
        if (st == Status::Going && (NAV.fail == NavRes::FailedStuck || NAV.fail == NavRes::FailedOsc)) st = Status::Failed;
        if (st == Status::Going) { ST.status = st; break; }
        TR("exec", "%d:%d %s", (int)c.beh, c.target, st == Status::Done ? "done" : "failed");
        if (st == Status::Failed)
        {
            if (c.beh == Beh::Kill) { const int kf = ST.kfail((u32)c.target); ST.exclude(c.beh, c.target, kf > r + EXCL ? kf : r + EXCL); }
            else ST.exclude(c.beh, c.target, r + EXCL);
        }
        ST.status = st;
    }
}

static void turn()
{
    const auto f0 = fuel();
    World& w = WORLD;
    sense(w, S, MEM, ST.cur.beh == Beh::Farm ? ST.cur.target : -1);
    Comms::decode(w, S);
    { const auto c = f0 - fuel(); if (c > PH[0]) PH[0] = c; }
    const bool f_attacked = ST.attacked, f_capt = ST.capt, f_waiting = ST.waiting;
    ST.attacked = ST.capt = ST.waiting = false;
    NAV.begin(S);
    if (f_attacked) ST.hit = true;
    if (!S.alive) { dead_gate(w); MEM.last_hp = 0; return; }
    MEM.update(w, S);
    pre_turn(w, S, MEM);
    reflexes(w);
    guards(w, f_attacked, f_capt, f_waiting);
    act(w);
    if (!(S.recalling || S.submitting) && fuel() > 12000)
    {
        const auto fb = fuel();
        scan_ward(w, S);
        { const auto cc = fb - fuel(); if (cc > PH[3]) PH[3] = cc; }
    }
    Comms::encode(w, S, ST.cur.beh, ST.cur.target);
    NAV.order(w, S, ST.capt);
    // act counters
    { const int k = (S.recalling || S.submitting) ? 3 : ST.attacked ? 1 : ST.capt ? 2 : ST.waiting ? 4 : NAV.moved ? 0 : 5; ST.act[k]++; ST.idle = k == 5 ? ST.idle + 1 : 0; if (ST.idle == 4) TR("idle", "%d:%d", (int)ST.cur.beh, ST.cur.target); }
    NE4 = S.near_e <= FRESH_E;
    MEM.last_pos = S.pos; MEM.last_hp = S.hp; MEM.last_bag = S.bag; MEM.last_gold = S.gold;
    // F_home lazily when the turn has room (one field)
    if (!w.have_home && fuel() > NAV.field_cost + 5000) { bitboard vis; w.F_home.compute(w.blk, w.sp, vis, FAR - 1); w.have_home = true; }
    const auto used = f0 - fuel();
    FSUM += used; ++FN; if (used > FMAX) FMAX = used; if (used > 99000) ++ROLL;
    if (S.r % 50 == 0)
    {
        TR("tick", "beh=%d:%d hp=%.0f bag=%d gold=%d fmax=%llu fmean=%llu roll=%d errs=%d deaths=%d score=%d-%d shards=%d str=%.0f act=%d/%d/%d/%d/%d/%d/%d dec=%d/%d/%d dcost=%u,%u nav=%u/%u/%u/%u/%u/%u/%u/%u ph=%llu/%llu/%llu/%llu",
           (int)ST.cur.beh, ST.cur.target, S.hp, S.bag, S.gold, (unsigned long long)FMAX, (unsigned long long)(FN ? FSUM / FN : 0), ROLL, ERRS, ST.deaths, S.score_us, S.score_them, ME.shards, S.S,
           ST.act[0], ST.act[1], ST.act[2], ST.act[3], ST.act[4], ST.act[5], ST.act[6], NDECS[0], NDECS[1], NDECS[2], dec_cost(0), dec_cost(1),
           NAV.n[0], NAV.n[1], NAV.n[2], NAV.n[3], NAV.n[4], NAV.n[5], NAV.n[6], NAV.n[7], (unsigned long long)PH[0], (unsigned long long)PH[1], (unsigned long long)PH[2], (unsigned long long)PH[3]);
        PH[0] = PH[1] = PH[2] = PH[3] = 0; FMAX = 0; FSUM = 0; FN = 0;
        for (int i = 0; i < 7; ++i) ST.act[i] = 0; NDECS[0] = NDECS[1] = NDECS[2] = 0; for (int i = 0; i < 8; ++i) NAV.n[i] = 0;
    }
}

static void boot_play()
{
    const auto f0 = fuel();
    WORLD.boot(); MEM.init(WORLD); KIT.init(WORLD); NAV.init(WORLD); ST.init(); ME.init(WORLD);
    CDEC[0][0] = DEC_COST0; CDEC[1][0] = DEC_COST0 / 2;
    ST.cur = Choice{ Beh::Idle, -1 }; ST.status = Status::Done;
    MEM.last_pos = WORLD.me->position();
    // the opening seed
    try
    {
        const int r = (int)cambc::round_number();
        const int seed = opening_seed(WORLD, r);
        if (seed >= 0)
        {
            sense(WORLD, S, MEM, -1); Comms::decode(WORLD, S); pre_turn(WORLD, S, MEM);
            upd_start(WORLD, S, MEM, Choice{ Beh::Farm, seed }, r);
            ST.seed = seed; ST.seed_until = SEED_UNTIL;
            TR("choice", "farm g%d seed slot=%d team=%d with=%d", seed, WORLD.slot, sub_size(WORLD), WORLD.slot < 6 ? ST.subs[WORLD.slot] : 0);
            Comms::encode(WORLD, S, Beh::Farm, seed);
        }
    }
    catch (const std::exception& e) { ++ERRS; TR("err", "seed %s", e.what()); }
    BOOTED = true;
    TR("boot", "total=%llu left=%llu", (unsigned long long)(f0 - fuel()), (unsigned long long)fuel());
}

int main()
{
    while (true)
    {
        try
        {
            if (cambc::is_draft()) draft_turn();
            else
            {
                if (!BOOTED) { boot_play(); cambc::end_turn(); continue; }   // the first turn boots and seeds only
                turn();
            }
        }
        catch (const std::exception& e) { ++ERRS; TR("err", "%s", e.what()); }
        catch (...) { ++ERRS; TR("err", "unknown"); }
        cambc::end_turn();
    }
}
