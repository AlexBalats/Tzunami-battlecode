// Draft: picks and the map model (DESIGN §4). draft_turn() is called once per draft turn by main.cpp.
#pragma once
#include "types.h"

constexpr int PICKS[6] = { 9, 1, 8, 0, 2, 6 };          // Varg, Vesper, Ren, Ryth, Vendetta, Marcella [R9]
constexpr int BACKUP[6] = { 11, 3, 4, 5, 7, 10 };       // Heart of Ruin first, then the rest [R9 X6 guess]
constexpr int R_REACT = 8;                              // side margin [R9]
constexpr float KEEP_FRAC = 0.4f;
constexpr int ALTAR_FIELDS_MAX = 8;                     // tie-break fields per draft [guess]
constexpr u32 DRAFT_RESERVE = 20000;                    // fuel left after a draft turn's last stage [guess]

void draft_turn();
